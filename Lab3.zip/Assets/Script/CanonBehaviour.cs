using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanonBehaviour : MonoBehaviour
{

    public float FireButtonPressedTime = 0.0f;
    public float MaxTime = 3.0f;
    public GameObject bulletToSpawn;
    public GameObject bulletSpawnPoint;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetButton("Fire1"))
        {
            FireButtonPressedTime += Time.deltaTime;
        }

        if (Input.GetButtonUp("Fire1"))
        {
            float ratio = FireButtonPressedTime / MaxTime;
            ratio = Mathf.Clamp(ratio, 0.0f, 1.0f);
            
            GameObject bullet = Instantiate(bulletToSpawn, bulletSpawnPoint.transform.position, bulletSpawnPoint.transform.rotation);


            BulletComponent bulletComponent = bullet.GetComponent<BulletComponent>();
            if (bulletComponent != null )
            {
                bulletComponent.strengthRatio = ratio;
            }
            FireButtonPressedTime = 0.0f;
        }
        
    }
}
