using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{

    Rigidbody rb;
    public float speedValue = 50.0f; //constant speed
    public float rotationSpeed = 10.0f;

    float rotationY = 0f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float verticalInput = Input.GetAxis("Vertical");
        float horizontalInput = Input.GetAxis("Horizontal");

        Vector3 forwardMovement = verticalInput * transform.forward;
        Vector3 rightMovement = horizontalInput * transform.right;
        Vector3 direction = (rightMovement + forwardMovement);
        direction.Normalize();

        float mouseX = Input.GetAxis("Mouse X");


        rb.AddForce(direction * speedValue);

        rotationY += mouseX;

        transform.rotation = Quaternion.Euler(0.0f, rotationY, 0.0f);
    }
}
